# Spring-MVC-JDBC-Rest-Webservice-Maven-Example
Spring MVC +Spring JDBC +Spring Rest Configuration With Maven in Eclipse IDE

This Example URL for getting JSON WS Response.

http://localhost:8080/SpringMVC_JDBC_Rest_Configuration/examples

By using This method exmple we can pass parameter through URL

http://localhost:8080/SpringMVC_JDBC_Rest_Configuration/example/1
